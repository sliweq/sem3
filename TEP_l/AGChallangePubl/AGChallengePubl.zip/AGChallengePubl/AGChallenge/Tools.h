#pragma once
#include  "atlstr.h"  //CString
#include  <math.h>
#include  <time.h>

#include <windows.h>



namespace  Tools
{
	void  vShow(CString  sText);
	void  vShow(int  iVal);
	void  vShow(double  dVal);
};//namespace  Tools